"""Evaluator-guided variable neighborhood descent."""
