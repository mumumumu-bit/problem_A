"""Development figures explicitly distinguish algorithm baseline from single core."""
import csv
import json
from pathlib import Path
import statistics
import warnings
from .style import apply_style,save,COLORS,LABELS


def plot_benchmark(directory):
    directory=Path(directory)
    try:
        plt=apply_style()
    except ImportError:
        warnings.warn('Matplotlib is unavailable; benchmark CSV remains usable. Install the dev extra to plot.')
        return []
    rows=list(csv.DictReader((directory/'benchmark.csv').open(encoding='utf-8')))
    for r in rows:
        for key in ('problem','cores','makespan','added_copy_bytes'):
            r[key]=int(r[key])
        r['runtime']=float(r['runtime'])
    figures=directory/'figures'
    baselines={(r['case'],r['problem'],r['cores']):r['makespan'] for r in rows if r['algorithm']=='baseline'}
    single={}
    if (directory/'singlecore.csv').exists():
        single={r['case']:int(r['makespan']) for r in csv.DictReader((directory/'singlecore.csv').open(encoding='utf-8'))}
    for problem in sorted({r['problem'] for r in rows}):
        fig,ax=plt.subplots()
        for alg,marker,line in [('baseline','o','--'),('multiseed','s','-.'),('vns','^','-')]:
            ns=sorted({r['cores'] for r in rows if r['problem']==problem})
            values=[]
            for n in ns:
                group=[r for r in rows if r['problem']==problem and r['cores']==n and r['algorithm']==alg]
                values.append(statistics.mean((single[r['case']] if single and problem in (1,2) else baselines[r['case'],problem,n])/r['makespan'] for r in group))
            if single and problem in (1,2):
                ns,values=[1]+ns,[1]+values
            ax.plot(ns,values,marker=marker,linestyle=line,color=COLORS[alg],label=LABELS[alg])
        ax.set(xlabel='Number of cores',ylabel='Mean per-case speedup' if single and problem in (1,2) else 'Mean speedup over load-balanced baseline',xticks=ns)
        ax.legend()
        save(fig,figures,f'p{problem}_speedup'); plt.close(fig)
    # Relative makespan avoids mixing cycle scales across heterogeneous cases.
    fig,ax=plt.subplots()
    for j,alg in enumerate(('baseline','multiseed','vns')):
        vals=[r['makespan']/baselines[r['case'],r['problem'],r['cores']] for r in rows if r['algorithm']==alg]
        ax.bar(j,statistics.mean(vals),color=COLORS[alg],width=.6)
    ax.set(xticks=range(3),xticklabels=[LABELS[a] for a in ('baseline','multiseed','vns')],ylabel='Mean normalized makespan')
    save(fig,figures,'ablation'); plt.close(fig)
    fig,ax=plt.subplots()
    for alg,marker in [('baseline','o'),('multiseed','s'),('vns','^')]:
        group=[r for r in rows if r['algorithm']==alg]
        ax.scatter([r['runtime'] for r in group],[r['makespan']/baselines[r['case'],r['problem'],r['cores']] for r in group],
            c=COLORS[alg],marker=marker,label=LABELS[alg],s=25,alpha=.7)
    ax.set(xlabel='Cumulative solver wall time (s)',ylabel='Makespan / load-balanced makespan',xscale='log'); ax.legend()
    save(fig,figures,'runtime_quality'); plt.close(fig)
    p2={(r['case'],r['cores']):r for r in rows if r['problem']==2 and r['algorithm']=='vns'}
    p3={(r['case'],r['cores']):r for r in rows if r['problem']==3 and r['algorithm']=='vns'}
    if p2 and p3:
        fig,ax=plt.subplots()
        ns=sorted({n for _,n in p2})
        values=[statistics.mean(p2[c,n]['makespan']/p3[c,n]['makespan'] for c,k in p2 if k==n and (c,n) in p3) for n in ns]
        ax.plot(ns,[1]*len(ns),'o--',color=COLORS['no_l2'],label='No L2')
        ax.plot(ns,values,'s-',color=COLORS['l2'],label='L2 (independently optimized)')
        ax.set(xlabel='Number of cores',ylabel='Mean no-L2 / L2 makespan',xticks=ns); ax.legend()
        save(fig,figures,'p3_l2_comparison'); plt.close(fig)
    captions={'scope':'Development subset only; not the final 100-case competition experiment.',
        'speedup':'Mean of per-case ratios; singlecore.csv is the independent official single-core baseline.',
        'ablation':'Nested baseline, multi-seed and VNS checkpoints under the same run.',
        'runtime':'Cumulative wall time including earlier algorithm stages; CLI verification excluded.',
        'l2':'Independent P2/P3 optimization confounds placement changes and cache benefit; not a controlled same-plan cache ablation.'}
    (figures/'captions.json').write_text(json.dumps(captions,indent=2),encoding='utf-8')
    return sorted(figures.glob('*.png'))
