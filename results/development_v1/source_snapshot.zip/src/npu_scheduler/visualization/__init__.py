"""Optional publication plots. Solving never imports Matplotlib."""
