"""Workload and tensor-aware DAG coarsening."""
