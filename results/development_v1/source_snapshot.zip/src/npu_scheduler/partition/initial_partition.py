"""Four distinct seed families and a safe whole-graph fallback."""
from .coarsening import coarsen
from ..schedule.core_assignment import assign
from ..types import Solution


def seeds(graph, cores, problem, hardware, config):
    yield 'baseline', assign(graph,coarsen(graph,cores,config.grains[len(config.grains)//2],'balanced',config),cores,'balanced',problem,hardware,config)
    # Whole-graph candidate is also valuable for long chains and bandwidth limits.
    yield 'whole', Solution((tuple(graph.topo),) if graph.n else (), (0,) if graph.n else (),cores)
    for grain in config.grains:
        for mode in ('affinity','critical','pipe','balanced'):
            yield f'{mode}-{grain}', assign(graph,coarsen(graph,cores,grain,mode,config),cores,mode,problem,hardware,config)
