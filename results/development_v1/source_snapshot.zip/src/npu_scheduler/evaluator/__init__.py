"""Official evaluator integration, without modifications to official sources."""
