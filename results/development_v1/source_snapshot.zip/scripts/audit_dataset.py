"""Read and validate all official cases; no evaluator experiments."""
from run_all import main
import sys
if __name__=='__main__':
    main(['audit',*sys.argv[1:]])
