"""Generate figures from actual benchmark records."""
from run_all import main
import sys
if __name__=='__main__':
    main(['plot',*sys.argv[1:]])
