"""Fixed development benchmark entry point."""
from run_all import main
import sys
if __name__=='__main__':
    main(['benchmark',*sys.argv[1:]])
