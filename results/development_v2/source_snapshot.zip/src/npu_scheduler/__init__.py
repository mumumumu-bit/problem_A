# 本程序及代码是在人工智能工具辅助下完成的。
# AI工具：
# 模型/版本：
# 开发机构：
# 版本发布日期：
"""Portable NPU scheduling research implementation."""
__version__ = "0.1.0"

